/*
 * vim: filetype=c:fenc=utf-8:ts=4:et:sw=4:sts=4
 */
#include <inttypes.h>
#include <stddef.h>
#include <math.h>
#include <stdio.h>
#include <sys/mman.h>
#include <syscall.h>
#include <netinet/in.h>
#include <stdlib.h>
#include "graphics.h"

extern void *tlsf_create_with_pool(void* mem, size_t bytes);
extern void *g_heap;

/**
 * GCC insists on __main
 *    http://gcc.gnu.org/onlinedocs/gccint/Collect2.html
 */
void __main()
{
    size_t heap_size = 32*1024*1024;
    void  *heap_base = mmap(NULL, heap_size, PROT_READ|PROT_WRITE, MAP_PRIVATE|MAP_ANON, -1, 0);
    g_heap = tlsf_create_with_pool(heap_base, heap_size);
}

int is_leap(int year)
{
    if ((year % 400) == 0) return 1;
    if ((year % 100) == 0) return 0;
    if ((year % 4) == 0) return 1;
    return 0;
}

void print_chongqing_time(time_t t)
{
    long days;
    long sec_of_day;
    int year = 1970;
    int month = 0;
    int day;
    int hour, minute, second;
    int mdays[12];

    /* 重庆/中国时间：UTC+8 */
    t = t + 8 * 3600;

    days = t / 86400;
    sec_of_day = t % 86400;

    hour = sec_of_day / 3600;
    minute = (sec_of_day % 3600) / 60;
    second = sec_of_day % 60;

    while (1) {
        int ydays = is_leap(year) ? 366 : 365;
        if (days >= ydays) {
            days -= ydays;
            year++;
        } else {
            break;
        }
    }

    mdays[0] = 31;
    mdays[1] = is_leap(year) ? 29 : 28;
    mdays[2] = 31;
    mdays[3] = 30;
    mdays[4] = 31;
    mdays[5] = 30;
    mdays[6] = 31;
    mdays[7] = 31;
    mdays[8] = 30;
    mdays[9] = 31;
    mdays[10] = 30;
    mdays[11] = 31;

    while (days >= mdays[month]) {
        days -= mdays[month];
        month++;
    }

    day = (int)days + 1;

    printf("Chongqing Local Time : %04d-%02d-%02d %02d:%02d:%02d\n",
           year, month + 1, day, hour, minute, second);
}

/**
 * 第一个运行在用户模式的线程所执行的函数
 */
void main(void *pv)
{
    time_t t1, t2;

    printf("task #%d: I'm the first user task(pv=0x%08x)!\r\n",
            task_getid(), pv);

    t1 = time(&t2);

    printf("t1 = %ld\n", t1);
    printf("t2 = %ld\n", t2);

    if (t1 == t2)
        printf("OK: t1 == t2\n");
    else
        printf("ERROR: t1 != t2\n");

    print_chongqing_time(t1);

    while(1)
        ;
    task_exit(0);
}

