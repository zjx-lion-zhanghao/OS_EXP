#include <syscall.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graphics.h"

#define SCREEN_W        640
#define SCREEN_H        480
#define SORT_N          80
#define THREAD_COUNT    4
#define STACK_SIZE      32768
#define EQUAL_COUNT     20
#define FOOTER_HEIGHT   64

typedef struct _Elem {
    int value;
    int origin_id;
    COLORREF color;
} Elem;

typedef struct _SortTask {
    char name[16];
    Elem *arr;
    int n;
    int left;
    int top;
    int right;
    int bottom;
    int footer_left;
    int footer_top;
    int footer_right;
    int footer_bottom;
    unsigned char *stack;
    int tid;
    int algo_type;
    int done;
    time_t start_sec;
    unsigned int start_msec;
    time_t end_sec;
    unsigned int end_msec;
    char start_text[32];
    char end_text[32];
} SortTask;

void __main() {}

static unsigned char thread_stacks[THREAD_COUNT][STACK_SIZE];

static unsigned char font_digit[10][16] = {
    {0x00,0x3C,0x66,0x6E,0x76,0x66,0x66,0x66,0x66,0x66,0x66,0x76,0x6E,0x66,0x3C,0x00},
    {0x00,0x18,0x38,0x78,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x18,0x7E,0x00},
    {0x00,0x3C,0x66,0x66,0x06,0x0C,0x18,0x30,0x60,0x60,0x60,0x60,0x66,0x66,0x7E,0x00},
    {0x00,0x3C,0x66,0x66,0x06,0x06,0x1C,0x1C,0x06,0x06,0x06,0x06,0x66,0x66,0x3C,0x00},
    {0x00,0x0C,0x1C,0x3C,0x6C,0xCC,0x8C,0xFE,0x0C,0x0C,0x0C,0x0C,0x0C,0x0C,0x1E,0x00},
    {0x00,0x7E,0x60,0x60,0x60,0x60,0x7C,0x66,0x06,0x06,0x06,0x06,0x66,0x66,0x3C,0x00},
    {0x00,0x1C,0x30,0x60,0x60,0x60,0x7C,0x66,0x66,0x66,0x66,0x66,0x66,0x66,0x3C,0x00},
    {0x00,0x7E,0x66,0x06,0x06,0x0C,0x0C,0x18,0x18,0x18,0x30,0x30,0x30,0x30,0x30,0x00},
    {0x00,0x3C,0x66,0x66,0x66,0x66,0x3C,0x3C,0x66,0x66,0x66,0x66,0x66,0x66,0x3C,0x00},
    {0x00,0x3C,0x66,0x66,0x66,0x66,0x66,0x3E,0x06,0x06,0x06,0x06,0x0C,0x18,0x38,0x00}
};

static unsigned char font_dash[16]  = {0,0,0,0,0,0,0x7E,0x7E,0,0,0,0,0,0,0,0};
static unsigned char font_colon[16] = {0,0,0,0x18,0x18,0,0,0,0,0x18,0x18,0,0,0,0,0};
static unsigned char font_dot[16]   = {0,0,0,0,0,0,0,0,0,0,0,0,0x18,0x18,0,0};
static unsigned char font_space[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

static unsigned char tiny_digit[10][7] = {
    {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E},
    {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},
    {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F},
    {0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E},
    {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02},
    {0x1F,0x10,0x10,0x1E,0x01,0x01,0x1E},
    {0x06,0x08,0x10,0x1E,0x11,0x11,0x0E},
    {0x1F,0x01,0x02,0x04,0x08,0x08,0x08},
    {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E},
    {0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C}
};

static unsigned char tiny_dash[7]  = {0x00,0x00,0x00,0x1F,0x00,0x00,0x00};
static unsigned char tiny_colon[7] = {0x00,0x04,0x04,0x00,0x04,0x04,0x00};
static unsigned char tiny_dot[7]   = {0x00,0x00,0x00,0x00,0x00,0x0C,0x0C};
static unsigned char tiny_space[7] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00};

static COLORREF blue_gradient_color(int i)
{
    int g;
    int b;

    if (i < 0)
        i = 0;
    if (i >= EQUAL_COUNT)
        i = EQUAL_COUNT - 1;

    g = i * 210 / (EQUAL_COUNT - 1);
    b = 80 + i * 175 / (EQUAL_COUNT - 1);
    return RGB(0, g, b);
}

static COLORREF yellow_gradient_color(int i)
{
    int v;

    if (i < 0)
        i = 0;
    if (i >= EQUAL_COUNT)
        i = EQUAL_COUNT - 1;

    v = 50 + i * 205 / (EQUAL_COUNT - 1);
    return RGB(v, v, 0);
}

static void delay(void)
{
    volatile int i;
    for (i = 0; i < 50000; i++) ;
}

static void clear_rect(int l, int t, int r, int b, COLORREF c)
{
    int x, y;

    if (l < 0) l = 0;
    if (t < 0) t = 0;
    if (r >= SCREEN_W) r = SCREEN_W - 1;
    if (b >= SCREEN_H) b = SCREEN_H - 1;

    for (y = t; y <= b; y++) {
        for (x = l; x <= r; x++)
            setPixel(x, y, c);
    }
}

static void clear_screen(void)
{
    clear_rect(0, 0, SCREEN_W - 1, SCREEN_H - 1, RGB(0, 0, 0));
}

static void draw_border(int l, int t, int r, int b, COLORREF c)
{
    int x, y;
    for (x = l; x <= r; x++) {
        setPixel(x, t, c);
        setPixel(x, b, c);
    }
    for (y = t; y <= b; y++) {
        setPixel(l, y, c);
        setPixel(r, y, c);
    }
}

static void draw_char8x16(int x, int y, char ch, COLORREF c)
{
    unsigned char *glyph;
    int row, col;

    if (ch >= '0' && ch <= '9')
        glyph = font_digit[ch - '0'];
    else if (ch == '-')
        glyph = font_dash;
    else if (ch == ':')
        glyph = font_colon;
    else if (ch == '.')
        glyph = font_dot;
    else
        glyph = font_space;

    for (row = 0; row < 16; row++) {
        for (col = 0; col < 8; col++) {
            if (glyph[row] & (1 << (7 - col)))
                setPixel(x + col, y + row, c);
        }
    }
}

static void draw_text8x16(int x, int y, const char *s, COLORREF c)
{
    while (*s) {
        draw_char8x16(x, y, *s, c);
        x += 8;
        s++;
    }
}

static void draw_char5x7(int x, int y, char ch, COLORREF c)
{
    unsigned char *glyph;
    int row, col;

    if (ch >= '0' && ch <= '9')
        glyph = tiny_digit[ch - '0'];
    else if (ch == '-')
        glyph = tiny_dash;
    else if (ch == ':')
        glyph = tiny_colon;
    else if (ch == '.')
        glyph = tiny_dot;
    else
        glyph = tiny_space;

    for (row = 0; row < 7; row++) {
        for (col = 0; col < 5; col++) {
            if (glyph[row] & (1 << (4 - col)))
                setPixel(x + col, y + row, c);
        }
    }
}

static void draw_text5x7(int x, int y, const char *s, COLORREF c)
{
    while (*s) {
        draw_char5x7(x, y, *s, c);
        x += 6;
        s++;
    }
}

static int is_leap(int year)
{
    if ((year % 400) == 0) return 1;
    if ((year % 100) == 0) return 0;
    if ((year % 4) == 0) return 1;
    return 0;
}

static int days_of_month(int year, int month)
{
    static int mdays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};

    if (month == 2 && is_leap(year))
        return 29;
    return mdays[month - 1];
}

static void unix_to_datetime(time_t sec,
                             int *year, int *month, int *day,
                             int *hour, int *minute, int *second)
{
    long days;
    long sec_of_day;
    int y, m;

    sec += 8 * 3600;
    days = sec / 86400;
    sec_of_day = sec % 86400;

    *hour = sec_of_day / 3600;
    *minute = (sec_of_day % 3600) / 60;
    *second = sec_of_day % 60;

    y = 1970;
    while (days >= (is_leap(y) ? 366 : 365)) {
        days -= is_leap(y) ? 366 : 365;
        y++;
    }

    m = 1;
    while (days >= days_of_month(y, m)) {
        days -= days_of_month(y, m);
        m++;
    }

    *year = y;
    *month = m;
    *day = (int)days + 1;
}

static void format_time(time_t sec, unsigned int msec, char *buf)
{
    int year, month, day, hour, minute, second;

    unix_to_datetime(sec, &year, &month, &day, &hour, &minute, &second);
    sprintf(buf, "%04d-%02d-%02d %02d:%02d:%02d.%03u",
            year, month, day, hour, minute, second, msec);
}

static void draw_footer_one(SortTask *task)
{
    int x = task->footer_left + 4;
    int y = task->footer_top + 8;
    int width = task->footer_right - task->footer_left + 1;

    clear_rect(task->footer_left, task->footer_top,
               task->footer_right, task->footer_bottom,
               RGB(0, 0, 0));
    draw_border(task->footer_left, task->footer_top,
                task->footer_right, task->footer_bottom,
                RGB(255, 255, 255));

    if (width >= 192) {
        draw_text8x16(x, y, task->start_text, RGB(0, 255, 0));
        draw_text8x16(x, y + 20, task->end_text, RGB(255, 255, 0));
    } else {
        draw_text5x7(x, y, task->start_text, RGB(0, 255, 0));
        draw_text5x7(x, y + 16, task->end_text, RGB(255, 255, 0));
    }
}

static void swap_elem(Elem *a, Elem *b)
{
    Elem tmp = *a;
    *a = *b;
    *b = tmp;
}

static void shuffle(Elem *a, int n)
{
    int i, j;

    for (i = n - 1; i > 0; i--) {
        j = rand() % (i + 1);
        swap_elem(&a[i], &a[j]);
    }
}

static void mark_equal_order(Elem *base, int n)
{
    int i;
    int equal_idx = 0;

    for (i = 0; i < n; i++) {
        if (base[i].value == 50) {
            base[i].origin_id = equal_idx;
            base[i].color = blue_gradient_color(equal_idx);
            equal_idx++;
        }
    }
}

static void generate_base_array(Elem *base, int n)
{
    int i;

    for (i = 0; i < EQUAL_COUNT; i++) {
        base[i].value = 50;
        base[i].origin_id = i;
        base[i].color = blue_gradient_color(i);
    }

    for (i = EQUAL_COUNT; i < n; i++) {
        base[i].value = rand() % 100 + 1;
        if (base[i].value == 50)
            base[i].value = 51;
        base[i].origin_id = i;
        base[i].color = RGB(255, 255, 255);
    }

    shuffle(base, n);
    mark_equal_order(base, n);
}

static void copy_array(Elem *dst, Elem *src, int n)
{
    int i;
    for (i = 0; i < n; i++)
        dst[i] = src[i];
}

static void draw_region(SortTask *task)
{
    int i, x, bar_h;
    int width;
    int height;
    int usable_w;

    clear_rect(task->left, task->top, task->right, task->bottom, RGB(0, 0, 0));
    draw_border(task->left, task->top, task->right, task->bottom, RGB(255, 255, 255));

    width = task->right - task->left + 1;
    height = task->bottom - task->top + 1;
    usable_w = width - 2;

    for (i = 0; i < task->n; i++) {
        x = task->left + 1 + i * usable_w / task->n;
        bar_h = task->arr[i].value * (height - 4) / 100;
        line(x, task->bottom - 1, x, task->bottom - 1 - bar_h,
             task->arr[i].color);

        if (task->arr[i].value == 50) {
            int mark_h = 4 + task->arr[i].origin_id;
            int gap = 6;
            int mark_bottom = task->bottom - 1 - bar_h - gap;
            int mark_top = mark_bottom - mark_h;

            if (mark_top < task->top + 1)
                mark_top = task->top + 1;
            if (mark_bottom > task->top + 1 && mark_top <= mark_bottom)
                line(x, mark_bottom,
                 x, mark_top,
                 yellow_gradient_color(task->arr[i].origin_id));
        }
    }
}

static void bubble_sort_visual(SortTask *task)
{
    int i, j;
    for (i = 0; i < task->n - 1; i++) {
        for (j = 0; j < task->n - 1 - i; j++) {
            if (task->arr[j].value > task->arr[j + 1].value) {
                swap_elem(&task->arr[j], &task->arr[j + 1]);
                draw_region(task);
                delay();
            }
        }
    }
}

static void insertion_sort_visual(SortTask *task)
{
    int i, j;
    Elem key;

    for (i = 1; i < task->n; i++) {
        key = task->arr[i];
        j = i - 1;
        while (j >= 0 && task->arr[j].value > key.value) {
            task->arr[j + 1] = task->arr[j];
            j--;
            draw_region(task);
            delay();
        }
        task->arr[j + 1] = key;
        draw_region(task);
        delay();
    }
}

static int partition_visual(SortTask *task, int l, int r)
{
    int i, j;
    Elem pivot = task->arr[r];

    i = l - 1;
    for (j = l; j < r; j++) {
        if (task->arr[j].value <= pivot.value) {
            i++;
            swap_elem(&task->arr[i], &task->arr[j]);
            draw_region(task);
            delay();
        }
    }

    swap_elem(&task->arr[i + 1], &task->arr[r]);
    draw_region(task);
    delay();

    return i + 1;
}

static void quick_sort_visual(SortTask *task, int l, int r)
{
    int p;
    if (l < r) {
        p = partition_visual(task, l, r);
        quick_sort_visual(task, l, p - 1);
        quick_sort_visual(task, p + 1, r);
    }
}

static void heapify_visual(SortTask *task, int n, int i)
{
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;

    if (l < n && task->arr[l].value > task->arr[largest].value)
        largest = l;
    if (r < n && task->arr[r].value > task->arr[largest].value)
        largest = r;

    if (largest != i) {
        swap_elem(&task->arr[i], &task->arr[largest]);
        draw_region(task);
        delay();
        heapify_visual(task, n, largest);
    }
}

static void heap_sort_visual(SortTask *task)
{
    int i;

    for (i = task->n / 2 - 1; i >= 0; i--)
        heapify_visual(task, task->n, i);

    for (i = task->n - 1; i > 0; i--) {
        swap_elem(&task->arr[0], &task->arr[i]);
        draw_region(task);
        delay();
        heapify_visual(task, i, 0);
    }
}

static void sort_thread(void *pv)
{
    SortTask *task = (SortTask *)pv;

    time_precise(&task->start_sec, &task->start_msec);
    format_time(task->start_sec, task->start_msec, task->start_text);
    task->end_text[0] = 0;

    draw_footer_one(task);
    draw_region(task);

    switch (task->algo_type) {
    case 0:
        bubble_sort_visual(task);
        break;
    case 1:
        insertion_sort_visual(task);
        break;
    case 2:
        quick_sort_visual(task, 0, task->n - 1);
        break;
    case 3:
        heap_sort_visual(task);
        break;
    }

    time_precise(&task->end_sec, &task->end_msec);
    format_time(task->end_sec, task->end_msec, task->end_text);
    task->done = 1;

    draw_region(task);
    draw_footer_one(task);
    task_exit(0);
}

static void init_task_region(SortTask *task, int idx, Elem *arr)
{
    int sort_h = SCREEN_H - FOOTER_HEIGHT;
    int col_w = SCREEN_W / THREAD_COUNT;

    task->arr = arr;
    task->n = SORT_N;
    task->stack = thread_stacks[idx];
    task->algo_type = idx;
    task->done = 0;
    task->start_text[0] = 0;
    task->end_text[0] = 0;

    task->left = idx * col_w;
    task->right = task->left + col_w - 1;
    task->top = 0;
    task->bottom = sort_h - 1;

    task->footer_left = task->left;
    task->footer_right = task->right;
    task->footer_top = sort_h;
    task->footer_bottom = SCREEN_H - 1;
}

void main(void *pv)
{
    Elem base[SORT_N];
    Elem thread_arrays[THREAD_COUNT][SORT_N];
    SortTask tasks[THREAD_COUNT];
    int i;

    (void)pv;

    init_graphic(0x111);
    clear_screen();

    srand(time(NULL));
    generate_base_array(base, SORT_N);

    for (i = 0; i < THREAD_COUNT; i++) {
        copy_array(thread_arrays[i], base, SORT_N);
        init_task_region(&tasks[i], i, thread_arrays[i]);
        draw_region(&tasks[i]);
        draw_footer_one(&tasks[i]);
    }

    strcpy(tasks[0].name, "Bubble");
    tasks[0].algo_type = 0;

    strcpy(tasks[1].name, "Insert");
    tasks[1].algo_type = 1;

    strcpy(tasks[2].name, "Quick");
    tasks[2].algo_type = 2;

    strcpy(tasks[3].name, "Heap");
    tasks[3].algo_type = 3;

    for (i = 0; i < THREAD_COUNT; i++)
        tasks[i].tid = task_create(tasks[i].stack + STACK_SIZE,
                                   sort_thread,
                                   &tasks[i]);

    while (1)
        delay();
}
